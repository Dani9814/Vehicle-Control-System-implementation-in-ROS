

/*
 * Include Files
 *
 */
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#include "rtwtypes.h"
#endif



/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */
# ifndef MATLAB_MEX_FILE

# include <Arduino.h>
# include <wiring_private.h>
        
typedef struct { int pinA; int pinB; long pos; int del;} Encoder;    
volatile Encoder Encs[3] = {{0,0,0,0}, {0,0,0,0}, {0,0,0,0}};

/* auxiliary function to handle encoder attachment           */
int getIntNums(int pin) {
/* returns the interrupt number for a given interrupt pin 
   see http://arduino.cc/it/Reference/AttachInterrupt        */
switch(pin) {
  case 2:
    return 0;
  case 3:
    return 1;
  case 21:
    return 2;
  case 20:
    return 3;
  case 19:
    return 4;
  case 18:
    return 5;   
  default:
    return -1;
  }
}


/* Interrupt Service Routine: change on pin B for Encoder 0  */
void isrPinBEn0(){ 
 static char dato;
 dato = PINE;
 if (dato & 0x20) // B
    {
    if (dato & 0x10) // A
          	Encs[0].pos++;
    else   	Encs[0].pos--;
 } else
    {
    if (dato & 0x10) // A
          	Encs[0].pos--;
    else   	Encs[0].pos++;
 }
} /* end ISR pin B Encoder 0  */




/* Interrupt Service Routine: change on pin B for Encoder 1  */
//void isrPinBEn1(){ 
 // int dato;
 //dato = PIND;
// if ((PIND & (1<<3))>0) // B
//    {
//    if ((PIND & (1<<2))>0) // A
//          	Enc[1].pos++;
//    else   	Enc[1].pos--;
// } else
//    {
//    if ((PIND & (1<<2))>0) // A
//          	Enc[1].pos--;
//    else   	Enc[1].pos++;
//}
// Enc[1].del=PIND;
//} /* end ISR pin B Encoder 1                                 */


# endif
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */
#define y_width 1
/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */
/* extern double func(double a); */
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output functions
 *
 */
void sfcn_direccion_Outputs_wrapper(real_T *pos,
			uint32_T *time,
			const real_T *xD,
			const uint8_T *enc, const int_T p_width0,
			const uint8_T *pinA, const int_T p_width1,
			const uint8_T *pinB, const int_T p_width2)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */
/* wait until after initialization is done */
if (xD[0]==1) {
        /* don't do anything for mex file generation */
    # ifndef MATLAB_MEX_FILE
        
        /* get encoder position and set is as output */
        
        //cli();//deshabilita interrupciones
        pos[0]=Encs[enc[0]].pos;
        time[0]=Encs[enc[0]].del;
        //time[0]=millis();//unidades en milisegundos
        //time[0]=micros();//unidades en microsegundos
        //sei();//habilita interrupciones
           
    # endif
    
}
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}

/*
 * Updates function
 *
 */
void sfcn_direccion_Update_wrapper(real_T *pos,
			uint32_T *time,
			real_T *xD,
			const uint8_T *enc, const int_T p_width0,
			const uint8_T *pinA, const int_T p_width1,
			const uint8_T *pinB, const int_T p_width2)
{
/* %%%-SFUNWIZ_wrapper_Update_Changes_BEGIN --- EDIT HERE TO _END */
if (xD[0]!=1) {
    
    /* don't do anything for MEX-file generation */
    # ifndef MATLAB_MEX_FILE
        pos[0]=0;
        /* enc[0] is the encoder number and it can be 0,1 or 2   */
        /* if other encoder blocks are present in the model      */
        /* up to a maximum of 3, they need to refer to a         */
        /* different encoder number                              */
            
        /* store pinA and pinB in global encoder structure Enc   */
        /* they will be needed later by the interrupt routine    */
        /* that will not be able to access s-function parameters */   

        Encs[enc[0]].pinA=pinA[0];      /* set pin A              */
        Encs[enc[0]].pinB=pinB[0];      /* set pin B              */
    
        /* set encoder pins as inputs                            */
//        pinMode(Enc[enc[0]].pinA, INPUT); 
//        pinMode(Enc[enc[0]].pinB, INPUT); 
        
        /* turn on pullup resistors                              */
//        digitalWrite(Enc[enc[0]].pinA, HIGH); 
//        digitalWrite(Enc[enc[0]].pinB, HIGH); 

        
            
        
        
        
        /* attach interrupts                                     */
        switch(enc[0]) {
          case 0:
           DDRE = DDRE & (0xff-0x30);
           PORTE = PORTE | 0x30;

           // attachInterrupt(getIntNum(Enc[0].pinA), irsPinAEn0, RISING);
            attachInterrupt(getIntNum(Encs[0].pinB), isrPinBEn0, CHANGE);
            break;  
          case 1:
//                 pinMode(Enc[enc[0]].pinA, INPUT); 
//                 pinMode(Enc[enc[0]].pinB, INPUT); 
//         
//         /* turn on pullup resistors                              */
            //DDRD = DDRD & (0xff- ((1<<2)|(1<<3)));
            //PORTD = PORTD | ((1<<2)|(1<<3));

//            digitalWrite(Enc[enc[0]].pinA, HIGH); 
//            digitalWrite(Enc[enc[0]].pinB, HIGH); 
            
            //attachInterrupt(getIntNum(Enc[1].pinA), irsPinAEn1, FALLING);
            //attachInterrupt(getIntNum(Enc[1].pinB), isrPinBEn1, CHANGE);
            break;  
          case 2:
          //  attachInterrupt(getIntNum(Enc[2].pinA), irsPinAEn2, RISING);
          //  attachInterrupt(getIntNum(Enc[2].pinB), isrPinBEn2, CHANGE);
            break;  
          }
  
        # endif
    
    /* initialization done */ 
    xD[0]=1;
}
/* %%%-SFUNWIZ_wrapper_Update_Changes_END --- EDIT HERE TO _BEGIN */
}
