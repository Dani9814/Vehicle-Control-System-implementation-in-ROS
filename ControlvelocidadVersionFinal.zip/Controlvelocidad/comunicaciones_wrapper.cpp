

/*
 * Include Files
 *
 */
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#include "rtwtypes.h"
#endif



/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */
#ifndef MATLAB_MEX_FILE
// include the library code:
  #include <Arduino.h>
  unsigned int mensaje[5];
  unsigned int mensaje2[8];
  unsigned int j,suma,signoV,signoW,vs1,vs0,ws1,ws0;
  unsigned int cheacksum;
#endif
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */
#define u_width 1
#define y_width 1
/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */
/* extern double func(double a); */
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output functions
 *
 */
extern "C" void comunicaciones_Outputs_wrapper(const int16_T *vsin,
			const int16_T *wsin,
			int16_T *vs,
			int16_T *ws,
			const real_T *xD)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */
/* This sample sets the output equal to the input
      y0[0] = u0[0]; 
 For complex signals use: y0[0].re = u0[0].re; 
      y0[0].im = u0[0].im;
      y1[0].re = u1[0].re;
      y1[0].im = u1[0].im;
 */

if(xD[0]==1){
    //Entrada de datos
    #ifndef MATLAB_MEX_FILE 
    if(Serial.available() > 0){ 
       if(Serial.read()==200){// cabecera
           if(Serial.read()==1){ //tipo
                 suma=200+1;
                 for(j=0;j<5;j++){
                     mensaje[j]=Serial.read();
                     suma=mensaje[j]+suma;
                 }

                 if(lowByte(suma)==0) //Cumple el cheacksum
                 {
                     if(mensaje[1]/128==0){
                        signoV=1;//Calculamos el signo
                     }
                     else{
                        signoV=-1;
                     } 
                     if(mensaje[3]/128==0){
                         signoW=1;
                     }
                     else{
                         signoW=-1;
                     }
                     vs[0]=signoV*(abs(mensaje[1]%128)*256+mensaje[0]);
                     ws[0]=signoW*(abs(mensaje[3]%128)*256+mensaje[2]);
                     //Si es correcto cambia la salida;   
                 }
       
           }
       }
    }
    //Salida de datos
        
        //Codificar datos
         if(vsin[0]<0)
         {
           vs1=128+abs(vsin[0]/256);
           vs0=abs(vsin[0]%256);
         }
         else
         {
           vs1=abs(vsin[0]/256);
           vs0=abs(vsin[0]%256);
         }
         if(wsin[0]<0)
         {
           ws1=128+abs(wsin[0]/256);
           ws0=abs(wsin[0]%256);
         }
         else
         {
           ws1=abs(wsin[0]/256);
           ws0=abs(wsin[0]%256);
         }
        mensaje2[0]=200;
        mensaje2[1]=1;
        mensaje2[2]=vs0;
        mensaje2[3]=vs1;
        mensaje2[4]=ws0;
        mensaje2[5]=ws1;
        
        
        //Calculo el cheacksum
        cheacksum=0;
        for (j=0;j<6;j++){
            cheacksum=mensaje2[j]+cheacksum;
        }
        if(cheacksum==256){ 
         mensaje2[6]=0;
        }
        else{
         mensaje2[6]=256-cheacksum%256;
        }
        
        //Envio los datos
        for (j=0;j<7;j++){ 
            Serial.write(mensaje2[j]);
        }
    
 #endif
}
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}

/*
 * Updates function
 *
 */
extern "C" void comunicaciones_Update_wrapper(const int16_T *vsin,
			const int16_T *wsin,
			int16_T *vs,
			int16_T *ws,
			real_T *xD)
{
/* %%%-SFUNWIZ_wrapper_Update_Changes_BEGIN --- EDIT HERE TO _END */
/*
 * Code example
 *   xD[0] = u0[0];
 */

 
if(xD[0]!=1)
{
#ifndef MATLAB_MEX_FILE
    Serial.begin(115200);
    vs[0]=0;
    ws[0]=0;
    while(Serial.available()>0)
    {
        Serial.read();
    }
#endif
  xD[0]=1;
  
}
/* %%%-SFUNWIZ_wrapper_Update_Changes_END --- EDIT HERE TO _BEGIN */
}
