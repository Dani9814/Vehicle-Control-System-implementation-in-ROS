/*
 * controlVelocidad_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "controlVelocidad".
 *
 * Model version              : 1.17
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Jun 28 17:23:39 2018
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controlVelocidad.h"
#include "controlVelocidad_private.h"

/* Block parameters (auto storage) */
P_controlVelocidad_T controlVelocidad_P = {
  -187.402904127994,                   /* Mask Parameter: PIDcarga_D
                                        * Referenced by: '<S25>/Derivative Gain'
                                        */
  0.0,                                 /* Mask Parameter: PIDsincarga_D
                                        * Referenced by: '<S26>/Derivative Gain'
                                        */
  0.341987494840097,                   /* Mask Parameter: PIDSincarga_D
                                        * Referenced by: '<S28>/Derivative Gain'
                                        */
  -0.0947507850623327,                 /* Mask Parameter: PIDConcarga_D
                                        * Referenced by: '<S27>/Derivative Gain'
                                        */
  3530.04970298017,                    /* Mask Parameter: PIDcarga_I
                                        * Referenced by: '<S25>/Integral Gain'
                                        */
  300.0,                               /* Mask Parameter: PIDsincarga_I
                                        * Referenced by: '<S26>/Integral Gain'
                                        */
  -6.93072814923136,                   /* Mask Parameter: PIDConcarga_I
                                        * Referenced by: '<S27>/Integral Gain'
                                        */
  15.2134081902195,                    /* Mask Parameter: PIDSincarga_I
                                        * Referenced by: '<S28>/Integral Gain'
                                        */
  0.0,                                 /* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                        * Referenced by: '<S15>/UD'
                                        */
  61.3503671932464,                    /* Mask Parameter: PIDcarga_N
                                        * Referenced by: '<S25>/Filter Coefficient'
                                        */
  75.5700458969935,                    /* Mask Parameter: PIDsincarga_N
                                        * Referenced by: '<S26>/Filter Coefficient'
                                        */
  11.2352356409556,                    /* Mask Parameter: PIDSincarga_N
                                        * Referenced by: '<S28>/Filter Coefficient'
                                        */
  6.11857544764302,                    /* Mask Parameter: PIDConcarga_N
                                        * Referenced by: '<S27>/Filter Coefficient'
                                        */
  16602.2408436558,                    /* Mask Parameter: PIDcarga_P
                                        * Referenced by: '<S25>/Proportional Gain'
                                        */
  120.0,                               /* Mask Parameter: PIDsincarga_P
                                        * Referenced by: '<S26>/Proportional Gain'
                                        */
  9.10843917922691,                    /* Mask Parameter: PIDSincarga_P
                                        * Referenced by: '<S28>/Proportional Gain'
                                        */
  -6.15783010496534,                   /* Mask Parameter: PIDConcarga_P
                                        * Referenced by: '<S27>/Proportional Gain'
                                        */
  2.0,                                 /* Mask Parameter: CompareToConstant_const
                                        * Referenced by: '<S29>/Constant'
                                        */
  6U,                                  /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S18>/PWM'
                                        */
  8U,                                  /* Mask Parameter: PWM_pinNumber_l
                                        * Referenced by: '<S23>/PWM'
                                        */
  9U,                                  /* Mask Parameter: PWM_pinNumber_a
                                        * Referenced by: '<S24>/PWM'
                                        */
  0.0,                                 /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S10>/Out1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/CARGA'
                                        */
  0.0015339807878856412,               /* Expression: pi/(1024*2)
                                        * Referenced by: '<S13>/1024cpr*2interrupcion Cuenta Flanco de subida y de bajada'
                                        */
  100.0,                               /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S15>/TSamp'
                                        */
  0.42971428571428572,                 /* Expression: 16*0.94/35
                                        * Referenced by: '<S12>/relacion transmision perdidas= 0.94 Rueda conductora 16 dientes Rueda conducida 35 dientes'
                                        */
  0.15,                                /* Expression: 0.15
                                        * Referenced by: '<S12>/Radio de la rueda= 15cm'
                                        */
  100.0,                               /* Expression: 100
                                        * Referenced by: '<S2>/Gain'
                                        */
  0.01,                                /* Expression: 360/(500*2*36)
                                        * Referenced by: '<S19>/pulses to degrees'
                                        */
  0.26315789473684209,                 /* Expression: 1/3.8
                                        * Referenced by: '<S19>/Reductora Dirección'
                                        */
  100.0,                               /* Expression: 100
                                        * Referenced by: '<S2>/Gain1'
                                        */
  0.017453292519943295,                /* Expression: pi/180
                                        * Referenced by: '<S2>/Gain2'
                                        */
  0.01,                                /* Expression: 0.01
                                        * Referenced by: '<S1>/Gain'
                                        */
  0.01,                                /* Expression: 0.01
                                        * Referenced by: '<S1>/Gain1'
                                        */
  57.295779513082323,                  /* Expression: 180/pi
                                        * Referenced by: '<Root>/Gain1'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S3>/Gain'
                                        */
  80.0,                                /* Expression: 80.0
                                        * Referenced by: '<S3>/Constant'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Constant2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Switch1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Constant1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S7>/Constant'
                                        */
  0.01,                                /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S25>/Integrator'
                                        */
  0.0,                                 /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S25>/Integrator'
                                        */
  0.01,                                /* Computed Parameter: Filter_gainval
                                        * Referenced by: '<S25>/Filter'
                                        */
  0.0,                                 /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S25>/Filter'
                                        */
  0.01,                                /* Computed Parameter: Integrator_gainval_a
                                        * Referenced by: '<S26>/Integrator'
                                        */
  0.0,                                 /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S26>/Integrator'
                                        */
  0.01,                                /* Computed Parameter: Filter_gainval_i
                                        * Referenced by: '<S26>/Filter'
                                        */
  0.0,                                 /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S26>/Filter'
                                        */
  55.0,                                /* Expression: 55
                                        * Referenced by: '<S7>/Switch'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Constant'
                                        */
  0.01,                                /* Computed Parameter: Integrator_gainval_f
                                        * Referenced by: '<S28>/Integrator'
                                        */
  0.0,                                 /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S28>/Integrator'
                                        */
  0.01,                                /* Computed Parameter: Filter_gainval_k
                                        * Referenced by: '<S28>/Filter'
                                        */
  0.0,                                 /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S28>/Filter'
                                        */
  0.01,                                /* Computed Parameter: Integrator_gainval_e
                                        * Referenced by: '<S27>/Integrator'
                                        */
  0.0,                                 /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S27>/Integrator'
                                        */
  0.01,                                /* Computed Parameter: Filter_gainval_p
                                        * Referenced by: '<S27>/Filter'
                                        */
  0.0,                                 /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S27>/Filter'
                                        */
  55.0,                                /* Expression: 55
                                        * Referenced by: '<S8>/Switch'
                                        */
  130.0,                               /* Expression: 130
                                        * Referenced by: '<S9>/Constant2'
                                        */
  2.0,                                 /* Expression: 2
                                        * Referenced by: '<S9>/Switch1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S21>/Constant'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S20>/Gain'
                                        */
  1U,                                  /* Expression: uint8(1)
                                        * Referenced by: '<S11>/EncoderIP2'
                                        */
  18U,                                 /* Expression: uint8(18)
                                        * Referenced by: '<S11>/EncoderIP2'
                                        */
  19U,                                 /* Expression: uint8(19)
                                        * Referenced by: '<S11>/EncoderIP2'
                                        */
  0U,                                  /* Expression: uint8(0)
                                        * Referenced by: '<S19>/EncoderDP2'
                                        */
  2U,                                  /* Expression: uint8(2)
                                        * Referenced by: '<S19>/EncoderDP2'
                                        */
  3U,                                  /* Expression: uint8(3)
                                        * Referenced by: '<S19>/EncoderDP2'
                                        */
  255U,                                /* Computed Parameter: Saturation_UpperSat
                                        * Referenced by: '<S14>/Saturation'
                                        */
  0U,                                  /* Computed Parameter: Saturation_LowerSat
                                        * Referenced by: '<S14>/Saturation'
                                        */
  255U,                                /* Computed Parameter: Saturation_UpperSat_g
                                        * Referenced by: '<S20>/Saturation'
                                        */
  0U,                                  /* Computed Parameter: Saturation_LowerSat_m
                                        * Referenced by: '<S20>/Saturation'
                                        */
  255U,                                /* Computed Parameter: Saturation1_UpperSat
                                        * Referenced by: '<S20>/Saturation1'
                                        */
  0U                                   /* Computed Parameter: Saturation1_LowerSat
                                        * Referenced by: '<S20>/Saturation1'
                                        */
};
