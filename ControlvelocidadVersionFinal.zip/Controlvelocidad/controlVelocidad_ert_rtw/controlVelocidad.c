/*
 * controlVelocidad.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "controlVelocidad".
 *
 * Model version              : 1.17
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Jun 28 17:23:39 2018
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controlVelocidad.h"
#include "controlVelocidad_private.h"
#define controlVelocidad_PinNumber     (5.0)
#define controlVelocidad_PinNumber_f   (7.0)

/* Block signals (auto storage) */
B_controlVelocidad_T controlVelocidad_B;

/* Block states (auto storage) */
DW_controlVelocidad_T controlVelocidad_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_controlVelocidad_T controlVelocidad_PrevZCX;

/* Real-time model */
RT_MODEL_controlVelocidad_T controlVelocidad_M_;
RT_MODEL_controlVelocidad_T *const controlVelocidad_M = &controlVelocidad_M_;
real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Model step function */
void controlVelocidad_step(void)
{
  /* local block i/o variables */
  real_T rtb_TSamp;
  real_T rtb_FilterCoefficient;
  real_T rtb_FilterCoefficient_m;
  real_T rtb_FilterCoefficient_k;
  real_T rtb_FilterCoefficient_e;
  real_T rtb_IntegralGain_d;
  uint8_T rtb_Sum_ci_0;

  /* S-Function (sfcn_encoder): '<S11>/EncoderIP2' */
  sfcn_encoder_Outputs_wrapper(&controlVelocidad_B.EncoderIP2_o1,
    &controlVelocidad_B.EncoderIP2_o2, &controlVelocidad_B.EncoderIP2_o3,
    &controlVelocidad_DW.EncoderIP2_DSTATE, &controlVelocidad_P.EncoderIP2_P1, 1,
    &controlVelocidad_P.EncoderIP2_P2, 1, &controlVelocidad_P.EncoderIP2_P3, 1);

  /* SampleTimeMath: '<S15>/TSamp' incorporates:
   *  DataTypeConversion: '<S11>/Data Type Conversion'
   *  Gain: '<S13>/1024cpr*2interrupcion Cuenta Flanco de subida y de bajada'
   *
   * About '<S15>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp = controlVelocidad_P.u024cpr2interrupcionCuentaFlanc * (real_T)
    controlVelocidad_B.EncoderIP2_o1 * controlVelocidad_P.TSamp_WtEt;

  /* Gain: '<S12>/Radio de la rueda= 15cm' incorporates:
   *  Gain: '<S12>/relacion transmision perdidas= 0.94 Rueda conductora 16 dientes Rueda conducida 35 dientes'
   *  Sum: '<S15>/Diff'
   *  UnitDelay: '<S15>/UD'
   */
  controlVelocidad_B.Radiodelarueda15cm = (rtb_TSamp -
    controlVelocidad_DW.UD_DSTATE) *
    controlVelocidad_P.relaciontransmisionperdidas094R *
    controlVelocidad_P.Radiodelarueda15cm_Gain;

  /* DataTypeConversion: '<S2>/Data Type Conversion' incorporates:
   *  Gain: '<S2>/Gain'
   *  Rounding: '<S2>/Round'
   */
  controlVelocidad_B.rtb_Gain_n_m = rt_roundd_snf(controlVelocidad_P.Gain_Gain *
    controlVelocidad_B.Radiodelarueda15cm);
  if (rtIsNaN(controlVelocidad_B.rtb_Gain_n_m) || rtIsInf
      (controlVelocidad_B.rtb_Gain_n_m)) {
    controlVelocidad_B.rtb_Gain_n_m = 0.0;
  } else {
    controlVelocidad_B.rtb_Gain_n_m = fmod(controlVelocidad_B.rtb_Gain_n_m,
      65536.0);
  }

  controlVelocidad_B.DataTypeConversion = controlVelocidad_B.rtb_Gain_n_m < 0.0 ?
    -(int16_T)(uint16_T)-controlVelocidad_B.rtb_Gain_n_m : (int16_T)(uint16_T)
    controlVelocidad_B.rtb_Gain_n_m;

  /* End of DataTypeConversion: '<S2>/Data Type Conversion' */

  /* S-Function (sfcn_direccion): '<S19>/EncoderDP2' */
  sfcn_direccion_Outputs_wrapper(&controlVelocidad_B.EncoderDP2_o1,
    &controlVelocidad_B.EncoderDP2_o2, &controlVelocidad_DW.EncoderDP2_DSTATE,
    &controlVelocidad_P.EncoderDP2_P1, 1, &controlVelocidad_P.EncoderDP2_P2, 1,
    &controlVelocidad_P.EncoderDP2_P3, 1);

  /* Gain: '<S19>/Reductora Dirección' incorporates:
   *  Gain: '<S19>/pulses to degrees'
   */
  controlVelocidad_B.ReductoraDireccin = controlVelocidad_P.pulsestodegrees_Gain
    * controlVelocidad_B.EncoderDP2_o1 *
    controlVelocidad_P.ReductoraDireccin_Gain;

  /* DataTypeConversion: '<S2>/Data Type Conversion1' incorporates:
   *  Gain: '<S2>/Gain1'
   *  Gain: '<S2>/Gain2'
   *  Rounding: '<S2>/Round1'
   */
  controlVelocidad_B.rtb_Gain_n_m = rt_roundd_snf(controlVelocidad_P.Gain1_Gain *
    controlVelocidad_B.ReductoraDireccin * controlVelocidad_P.Gain2_Gain);
  if (rtIsNaN(controlVelocidad_B.rtb_Gain_n_m) || rtIsInf
      (controlVelocidad_B.rtb_Gain_n_m)) {
    controlVelocidad_B.rtb_Gain_n_m = 0.0;
  } else {
    controlVelocidad_B.rtb_Gain_n_m = fmod(controlVelocidad_B.rtb_Gain_n_m,
      65536.0);
  }

  controlVelocidad_B.DataTypeConversion1 = controlVelocidad_B.rtb_Gain_n_m < 0.0
    ? -(int16_T)(uint16_T)-controlVelocidad_B.rtb_Gain_n_m : (int16_T)(uint16_T)
    controlVelocidad_B.rtb_Gain_n_m;

  /* End of DataTypeConversion: '<S2>/Data Type Conversion1' */

  /* S-Function (comunicaciones): '<Root>/S-Function Builder' */
  comunicaciones_Outputs_wrapper(&controlVelocidad_B.DataTypeConversion,
    &controlVelocidad_B.DataTypeConversion1,
    &controlVelocidad_B.SFunctionBuilder_o1,
    &controlVelocidad_B.SFunctionBuilder_o2,
    &controlVelocidad_DW.SFunctionBuilder_DSTATE);

  /* Gain: '<S1>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion'
   */
  controlVelocidad_B.Gain = controlVelocidad_P.Gain_Gain_j * (real_T)
    controlVelocidad_B.SFunctionBuilder_o1;

  /* Switch: '<S4>/Switch1' incorporates:
   *  Clock: '<S4>/Clock2'
   *  Constant: '<S4>/Constant2'
   */
  if (controlVelocidad_M->Timing.t[0] > controlVelocidad_P.Switch1_Threshold) {
    controlVelocidad_B.Gain_n = controlVelocidad_B.Gain;
  } else {
    controlVelocidad_B.Gain_n = controlVelocidad_P.Constant2_Value;
  }

  /* End of Switch: '<S4>/Switch1' */

  /* Sum: '<S3>/Sum1' */
  controlVelocidad_B.Sum1 = controlVelocidad_B.Gain_n -
    controlVelocidad_B.Radiodelarueda15cm;

  /* Switch: '<S7>/Switch1' incorporates:
   *  Constant: '<S7>/Constant'
   *  Constant: '<S7>/Constant1'
   */
  if (controlVelocidad_B.Gain_n != 0.0) {
    controlVelocidad_B.Switch1 = controlVelocidad_P.Constant1_Value;
  } else {
    controlVelocidad_B.Switch1 = controlVelocidad_P.Constant_Value_e;
  }

  /* End of Switch: '<S7>/Switch1' */

  /* DiscreteIntegrator: '<S25>/Integrator' */
  if ((controlVelocidad_B.Switch1 != 0.0) ||
      (controlVelocidad_DW.Integrator_PrevResetState != 0)) {
    controlVelocidad_DW.Integrator_DSTATE = controlVelocidad_P.Integrator_IC;
  }

  /* DiscreteIntegrator: '<S25>/Filter' */
  if ((controlVelocidad_B.Switch1 != 0.0) ||
      (controlVelocidad_DW.Filter_PrevResetState != 0)) {
    controlVelocidad_DW.Filter_DSTATE = controlVelocidad_P.Filter_IC;
  }

  /* Gain: '<S25>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S25>/Filter'
   *  Gain: '<S25>/Derivative Gain'
   *  Sum: '<S25>/SumD'
   */
  rtb_FilterCoefficient = (controlVelocidad_P.PIDcarga_D *
    controlVelocidad_B.Sum1 - controlVelocidad_DW.Filter_DSTATE) *
    controlVelocidad_P.PIDcarga_N;

  /* DiscreteIntegrator: '<S26>/Integrator' */
  if ((controlVelocidad_B.Switch1 != 0.0) ||
      (controlVelocidad_DW.Integrator_PrevResetState_a != 0)) {
    controlVelocidad_DW.Integrator_DSTATE_g = controlVelocidad_P.Integrator_IC_a;
  }

  /* DiscreteIntegrator: '<S26>/Filter' */
  if ((controlVelocidad_B.Switch1 != 0.0) ||
      (controlVelocidad_DW.Filter_PrevResetState_k != 0)) {
    controlVelocidad_DW.Filter_DSTATE_i = controlVelocidad_P.Filter_IC_l;
  }

  /* Gain: '<S26>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S26>/Filter'
   *  Gain: '<S26>/Derivative Gain'
   *  Sum: '<S26>/SumD'
   */
  rtb_FilterCoefficient_m = (controlVelocidad_P.PIDsincarga_D *
    controlVelocidad_B.Sum1 - controlVelocidad_DW.Filter_DSTATE_i) *
    controlVelocidad_P.PIDsincarga_N;

  /* Switch: '<S7>/Switch' incorporates:
   *  Constant: '<Root>/CARGA'
   *  DiscreteIntegrator: '<S25>/Integrator'
   *  DiscreteIntegrator: '<S26>/Integrator'
   *  Gain: '<S25>/Proportional Gain'
   *  Gain: '<S26>/Proportional Gain'
   *  Sum: '<S25>/Sum'
   *  Sum: '<S26>/Sum'
   */
  if (controlVelocidad_P.CARGA_Value > controlVelocidad_P.Switch_Threshold) {
    controlVelocidad_B.Sum_ci = (controlVelocidad_P.PIDcarga_P *
      controlVelocidad_B.Sum1 + controlVelocidad_DW.Integrator_DSTATE) +
      rtb_FilterCoefficient;
  } else {
    controlVelocidad_B.Sum_ci = (controlVelocidad_P.PIDsincarga_P *
      controlVelocidad_B.Sum1 + controlVelocidad_DW.Integrator_DSTATE_g) +
      rtb_FilterCoefficient_m;
  }

  /* End of Switch: '<S7>/Switch' */

  /* Start for MATLABSystem: '<S17>/Digital Output' incorporates:
   *  Constant: '<S16>/Constant'
   *  DataTypeConversion: '<S17>/Data Type Conversion'
   *  MATLABSystem: '<S17>/Digital Output'
   *  RelationalOperator: '<S16>/Compare'
   */
  writeDigitalPin((uint8_T)controlVelocidad_PinNumber, (uint8_T)
                  (controlVelocidad_B.Sum_ci >
                   controlVelocidad_P.Constant_Value_p));

  /* Abs: '<S14>/Abs1' */
  if (controlVelocidad_B.Sum_ci < 0.0) {
    controlVelocidad_B.rtb_Gain_n_m = floor(-controlVelocidad_B.Sum_ci);
    if (rtIsInf(controlVelocidad_B.rtb_Gain_n_m)) {
      rtb_Sum_ci_0 = 0U;
    } else {
      rtb_Sum_ci_0 = (uint8_T)fmod(controlVelocidad_B.rtb_Gain_n_m, 256.0);
    }
  } else {
    controlVelocidad_B.rtb_Gain_n_m = floor(controlVelocidad_B.Sum_ci);
    if (rtIsNaN(controlVelocidad_B.rtb_Gain_n_m) || rtIsInf
        (controlVelocidad_B.rtb_Gain_n_m)) {
      rtb_Sum_ci_0 = 0U;
    } else {
      rtb_Sum_ci_0 = (uint8_T)fmod(controlVelocidad_B.rtb_Gain_n_m, 256.0);
    }
  }

  /* End of Abs: '<S14>/Abs1' */

  /* Saturate: '<S14>/Saturation' */
  if (rtb_Sum_ci_0 > controlVelocidad_P.Saturation_UpperSat) {
    rtb_Sum_ci_0 = controlVelocidad_P.Saturation_UpperSat;
  } else {
    if (rtb_Sum_ci_0 < controlVelocidad_P.Saturation_LowerSat) {
      rtb_Sum_ci_0 = controlVelocidad_P.Saturation_LowerSat;
    }
  }

  /* End of Saturate: '<S14>/Saturation' */

  /* S-Function (arduinoanalogoutput_sfcn): '<S18>/PWM' */
  MW_analogWrite(controlVelocidad_P.PWM_pinNumber, rtb_Sum_ci_0);

  /* Clock: '<S9>/Clock2' */
  controlVelocidad_B.Gain_n = controlVelocidad_M->Timing.t[0];

  /* RelationalOperator: '<S29>/Compare' incorporates:
   *  Constant: '<S29>/Constant'
   */
  controlVelocidad_B.Compare = (controlVelocidad_B.Gain_n >
    controlVelocidad_P.CompareToConstant_const);

  /* Outputs for Triggered SubSystem: '<S3>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S10>/Trigger'
   */
  if (controlVelocidad_B.Compare &&
      (controlVelocidad_PrevZCX.TriggeredSubsystem_Trig_ZCE != POS_ZCSIG)) {
    /* Inport: '<S10>/In1' */
    controlVelocidad_B.In1 = controlVelocidad_B.ReductoraDireccin;
  }

  controlVelocidad_PrevZCX.TriggeredSubsystem_Trig_ZCE =
    controlVelocidad_B.Compare;

  /* End of Outputs for SubSystem: '<S3>/Triggered Subsystem' */

  /* Sum: '<S3>/Sum' incorporates:
   *  Constant: '<S3>/Constant'
   *  DataTypeConversion: '<S1>/Data Type Conversion1'
   *  Gain: '<Root>/Gain1'
   *  Gain: '<S1>/Gain1'
   *  Gain: '<S3>/Gain'
   *  Sum: '<S3>/Add'
   *  Sum: '<S3>/Sum2'
   */
  controlVelocidad_B.Sum_ci = (controlVelocidad_P.Gain1_Gain_j * (real_T)
    controlVelocidad_B.SFunctionBuilder_o2 * controlVelocidad_P.Gain1_Gain_n *
    controlVelocidad_P.Gain_Gain_l + controlVelocidad_P.Constant_Value) -
    (controlVelocidad_B.ReductoraDireccin - controlVelocidad_B.In1);

  /* DiscreteIntegrator: '<S28>/Integrator' */
  if (controlVelocidad_B.Compare &&
      (controlVelocidad_DW.Integrator_PrevResetState_l <= 0)) {
    controlVelocidad_DW.Integrator_DSTATE_b = controlVelocidad_P.Integrator_IC_c;
  }

  /* DiscreteIntegrator: '<S28>/Filter' */
  if (controlVelocidad_B.Compare && (controlVelocidad_DW.Filter_PrevResetState_d
       <= 0)) {
    controlVelocidad_DW.Filter_DSTATE_p = controlVelocidad_P.Filter_IC_n;
  }

  /* Gain: '<S28>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S28>/Filter'
   *  Gain: '<S28>/Derivative Gain'
   *  Sum: '<S28>/SumD'
   */
  rtb_FilterCoefficient_k = (controlVelocidad_P.PIDSincarga_D *
    controlVelocidad_B.Sum_ci - controlVelocidad_DW.Filter_DSTATE_p) *
    controlVelocidad_P.PIDSincarga_N;

  /* DiscreteIntegrator: '<S27>/Integrator' */
  if (controlVelocidad_B.Compare &&
      (controlVelocidad_DW.Integrator_PrevResetState_o <= 0)) {
    controlVelocidad_DW.Integrator_DSTATE_c = controlVelocidad_P.Integrator_IC_n;
  }

  /* DiscreteIntegrator: '<S27>/Filter' */
  if (controlVelocidad_B.Compare && (controlVelocidad_DW.Filter_PrevResetState_l
       <= 0)) {
    controlVelocidad_DW.Filter_DSTATE_m = controlVelocidad_P.Filter_IC_m;
  }

  /* Gain: '<S27>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S27>/Filter'
   *  Gain: '<S27>/Derivative Gain'
   *  Sum: '<S27>/SumD'
   */
  rtb_FilterCoefficient_e = (controlVelocidad_P.PIDConcarga_D *
    controlVelocidad_B.Sum_ci - controlVelocidad_DW.Filter_DSTATE_m) *
    controlVelocidad_P.PIDConcarga_N;

  /* Switch: '<S8>/Switch' incorporates:
   *  Constant: '<Root>/CARGA'
   *  DiscreteIntegrator: '<S27>/Integrator'
   *  DiscreteIntegrator: '<S28>/Integrator'
   *  Gain: '<S27>/Proportional Gain'
   *  Gain: '<S28>/Proportional Gain'
   *  Sum: '<S27>/Sum'
   *  Sum: '<S28>/Sum'
   */
  if (controlVelocidad_P.CARGA_Value > controlVelocidad_P.Switch_Threshold_b) {
    controlVelocidad_B.Switch = (controlVelocidad_P.PIDSincarga_P *
      controlVelocidad_B.Sum_ci + controlVelocidad_DW.Integrator_DSTATE_b) +
      rtb_FilterCoefficient_k;
  } else {
    controlVelocidad_B.Switch = (controlVelocidad_P.PIDConcarga_P *
      controlVelocidad_B.Sum_ci + controlVelocidad_DW.Integrator_DSTATE_c) +
      rtb_FilterCoefficient_e;
  }

  /* End of Switch: '<S8>/Switch' */

  /* Switch: '<S9>/Switch1' incorporates:
   *  Constant: '<S9>/Constant2'
   */
  if (controlVelocidad_B.Gain_n > controlVelocidad_P.Switch1_Threshold_a) {
    controlVelocidad_B.Gain_n = controlVelocidad_B.Switch;
  } else {
    controlVelocidad_B.Gain_n = controlVelocidad_P.Constant2_Value_n;
  }

  /* End of Switch: '<S9>/Switch1' */

  /* Start for MATLABSystem: '<S22>/Digital Output' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S22>/Data Type Conversion'
   *  MATLABSystem: '<S22>/Digital Output'
   *  RelationalOperator: '<S21>/Compare'
   */
  writeDigitalPin((uint8_T)controlVelocidad_PinNumber_f, (uint8_T)
                  (controlVelocidad_B.Gain_n !=
                   controlVelocidad_P.Constant_Value_k));

  /* Saturate: '<S20>/Saturation' */
  if (controlVelocidad_B.Gain_n > controlVelocidad_P.Saturation_UpperSat_g) {
    controlVelocidad_B.rtb_Gain_n_m = controlVelocidad_P.Saturation_UpperSat_g;
  } else if (controlVelocidad_B.Gain_n <
             controlVelocidad_P.Saturation_LowerSat_m) {
    controlVelocidad_B.rtb_Gain_n_m = controlVelocidad_P.Saturation_LowerSat_m;
  } else {
    controlVelocidad_B.rtb_Gain_n_m = controlVelocidad_B.Gain_n;
  }

  controlVelocidad_B.rtb_Gain_n_m = floor(controlVelocidad_B.rtb_Gain_n_m);
  if (rtIsNaN(controlVelocidad_B.rtb_Gain_n_m) || rtIsInf
      (controlVelocidad_B.rtb_Gain_n_m)) {
    controlVelocidad_B.Saturation = 0U;
  } else {
    controlVelocidad_B.Saturation = (uint8_T)fmod
      (controlVelocidad_B.rtb_Gain_n_m, 256.0);
  }

  /* End of Saturate: '<S20>/Saturation' */

  /* S-Function (arduinoanalogoutput_sfcn): '<S23>/PWM' */
  MW_analogWrite(controlVelocidad_P.PWM_pinNumber_l,
                 controlVelocidad_B.Saturation);

  /* Gain: '<S20>/Gain' */
  controlVelocidad_B.Gain_n *= controlVelocidad_P.Gain_Gain_d;

  /* Saturate: '<S20>/Saturation1' */
  if (controlVelocidad_B.Gain_n > controlVelocidad_P.Saturation1_UpperSat) {
    controlVelocidad_B.Gain_n = controlVelocidad_P.Saturation1_UpperSat;
  } else {
    if (controlVelocidad_B.Gain_n < controlVelocidad_P.Saturation1_LowerSat) {
      controlVelocidad_B.Gain_n = controlVelocidad_P.Saturation1_LowerSat;
    }
  }

  controlVelocidad_B.rtb_Gain_n_m = floor(controlVelocidad_B.Gain_n);
  if (rtIsNaN(controlVelocidad_B.rtb_Gain_n_m) || rtIsInf
      (controlVelocidad_B.rtb_Gain_n_m)) {
    controlVelocidad_B.Saturation1 = 0U;
  } else {
    controlVelocidad_B.Saturation1 = (uint8_T)fmod
      (controlVelocidad_B.rtb_Gain_n_m, 256.0);
  }

  /* End of Saturate: '<S20>/Saturation1' */

  /* S-Function (arduinoanalogoutput_sfcn): '<S24>/PWM' */
  MW_analogWrite(controlVelocidad_P.PWM_pinNumber_a,
                 controlVelocidad_B.Saturation1);

  /* Gain: '<S25>/Integral Gain' */
  controlVelocidad_B.IntegralGain = controlVelocidad_P.PIDcarga_I *
    controlVelocidad_B.Sum1;

  /* Gain: '<S26>/Integral Gain' */
  rtb_IntegralGain_d = controlVelocidad_P.PIDsincarga_I *
    controlVelocidad_B.Sum1;

  /* Gain: '<S27>/Integral Gain' */
  controlVelocidad_B.IntegralGain_b = controlVelocidad_P.PIDConcarga_I *
    controlVelocidad_B.Sum_ci;

  /* Gain: '<S28>/Integral Gain' */
  controlVelocidad_B.IntegralGain_m = controlVelocidad_P.PIDSincarga_I *
    controlVelocidad_B.Sum_ci;

  /* Update for S-Function (sfcn_encoder): '<S11>/EncoderIP2' */

  /* S-Function "sfcn_encoder_wrapper" Block: <S11>/EncoderIP2 */
  sfcn_encoder_Update_wrapper(&controlVelocidad_B.EncoderIP2_o1,
    &controlVelocidad_B.EncoderIP2_o2, &controlVelocidad_B.EncoderIP2_o3,
    &controlVelocidad_DW.EncoderIP2_DSTATE, &controlVelocidad_P.EncoderIP2_P1, 1,
    &controlVelocidad_P.EncoderIP2_P2, 1, &controlVelocidad_P.EncoderIP2_P3, 1);

  /* Update for UnitDelay: '<S15>/UD' */
  controlVelocidad_DW.UD_DSTATE = rtb_TSamp;

  /* Update for S-Function (sfcn_direccion): '<S19>/EncoderDP2' */

  /* S-Function "sfcn_direccion_wrapper" Block: <S19>/EncoderDP2 */
  sfcn_direccion_Update_wrapper(&controlVelocidad_B.EncoderDP2_o1,
    &controlVelocidad_B.EncoderDP2_o2, &controlVelocidad_DW.EncoderDP2_DSTATE,
    &controlVelocidad_P.EncoderDP2_P1, 1, &controlVelocidad_P.EncoderDP2_P2, 1,
    &controlVelocidad_P.EncoderDP2_P3, 1);

  /* Update for S-Function (comunicaciones): '<Root>/S-Function Builder' */

  /* S-Function "comunicaciones_wrapper" Block: <Root>/S-Function Builder */
  comunicaciones_Update_wrapper(&controlVelocidad_B.DataTypeConversion,
    &controlVelocidad_B.DataTypeConversion1,
    &controlVelocidad_B.SFunctionBuilder_o1,
    &controlVelocidad_B.SFunctionBuilder_o2,
    &controlVelocidad_DW.SFunctionBuilder_DSTATE);

  /* Update for DiscreteIntegrator: '<S25>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE += controlVelocidad_P.Integrator_gainval
    * controlVelocidad_B.IntegralGain;
  if (controlVelocidad_B.Switch1 > 0.0) {
    controlVelocidad_DW.Integrator_PrevResetState = 1;
  } else if (controlVelocidad_B.Switch1 < 0.0) {
    controlVelocidad_DW.Integrator_PrevResetState = -1;
  } else if (controlVelocidad_B.Switch1 == 0.0) {
    controlVelocidad_DW.Integrator_PrevResetState = 0;
  } else {
    controlVelocidad_DW.Integrator_PrevResetState = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S25>/Integrator' */

  /* Update for DiscreteIntegrator: '<S25>/Filter' */
  controlVelocidad_DW.Filter_DSTATE += controlVelocidad_P.Filter_gainval *
    rtb_FilterCoefficient;
  if (controlVelocidad_B.Switch1 > 0.0) {
    controlVelocidad_DW.Filter_PrevResetState = 1;
  } else if (controlVelocidad_B.Switch1 < 0.0) {
    controlVelocidad_DW.Filter_PrevResetState = -1;
  } else if (controlVelocidad_B.Switch1 == 0.0) {
    controlVelocidad_DW.Filter_PrevResetState = 0;
  } else {
    controlVelocidad_DW.Filter_PrevResetState = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S25>/Filter' */

  /* Update for DiscreteIntegrator: '<S26>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE_g +=
    controlVelocidad_P.Integrator_gainval_a * rtb_IntegralGain_d;
  if (controlVelocidad_B.Switch1 > 0.0) {
    controlVelocidad_DW.Integrator_PrevResetState_a = 1;
  } else if (controlVelocidad_B.Switch1 < 0.0) {
    controlVelocidad_DW.Integrator_PrevResetState_a = -1;
  } else if (controlVelocidad_B.Switch1 == 0.0) {
    controlVelocidad_DW.Integrator_PrevResetState_a = 0;
  } else {
    controlVelocidad_DW.Integrator_PrevResetState_a = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S26>/Integrator' */

  /* Update for DiscreteIntegrator: '<S26>/Filter' */
  controlVelocidad_DW.Filter_DSTATE_i += controlVelocidad_P.Filter_gainval_i *
    rtb_FilterCoefficient_m;
  if (controlVelocidad_B.Switch1 > 0.0) {
    controlVelocidad_DW.Filter_PrevResetState_k = 1;
  } else if (controlVelocidad_B.Switch1 < 0.0) {
    controlVelocidad_DW.Filter_PrevResetState_k = -1;
  } else if (controlVelocidad_B.Switch1 == 0.0) {
    controlVelocidad_DW.Filter_PrevResetState_k = 0;
  } else {
    controlVelocidad_DW.Filter_PrevResetState_k = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S26>/Filter' */

  /* Update for DiscreteIntegrator: '<S28>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE_b +=
    controlVelocidad_P.Integrator_gainval_f * controlVelocidad_B.IntegralGain_m;
  controlVelocidad_DW.Integrator_PrevResetState_l = (int8_T)
    controlVelocidad_B.Compare;

  /* Update for DiscreteIntegrator: '<S28>/Filter' */
  controlVelocidad_DW.Filter_DSTATE_p += controlVelocidad_P.Filter_gainval_k *
    rtb_FilterCoefficient_k;
  controlVelocidad_DW.Filter_PrevResetState_d = (int8_T)
    controlVelocidad_B.Compare;

  /* Update for DiscreteIntegrator: '<S27>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE_c +=
    controlVelocidad_P.Integrator_gainval_e * controlVelocidad_B.IntegralGain_b;
  controlVelocidad_DW.Integrator_PrevResetState_o = (int8_T)
    controlVelocidad_B.Compare;

  /* Update for DiscreteIntegrator: '<S27>/Filter' */
  controlVelocidad_DW.Filter_DSTATE_m += controlVelocidad_P.Filter_gainval_p *
    rtb_FilterCoefficient_e;
  controlVelocidad_DW.Filter_PrevResetState_l = (int8_T)
    controlVelocidad_B.Compare;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++controlVelocidad_M->Timing.clockTick0)) {
    ++controlVelocidad_M->Timing.clockTickH0;
  }

  controlVelocidad_M->Timing.t[0] = controlVelocidad_M->Timing.clockTick0 *
    controlVelocidad_M->Timing.stepSize0 +
    controlVelocidad_M->Timing.clockTickH0 *
    controlVelocidad_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.01, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    controlVelocidad_M->Timing.clockTick1++;
    if (!controlVelocidad_M->Timing.clockTick1) {
      controlVelocidad_M->Timing.clockTickH1++;
    }
  }
}

/* Model initialize function */
void controlVelocidad_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)controlVelocidad_M, 0,
                sizeof(RT_MODEL_controlVelocidad_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&controlVelocidad_M->solverInfo,
                          &controlVelocidad_M->Timing.simTimeStep);
    rtsiSetTPtr(&controlVelocidad_M->solverInfo, &rtmGetTPtr(controlVelocidad_M));
    rtsiSetStepSizePtr(&controlVelocidad_M->solverInfo,
                       &controlVelocidad_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&controlVelocidad_M->solverInfo, (&rtmGetErrorStatus
      (controlVelocidad_M)));
    rtsiSetRTModelPtr(&controlVelocidad_M->solverInfo, controlVelocidad_M);
  }

  rtsiSetSimTimeStep(&controlVelocidad_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&controlVelocidad_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(controlVelocidad_M, &controlVelocidad_M->Timing.tArray[0]);
  controlVelocidad_M->Timing.stepSize0 = 0.01;

  /* block I/O */
  (void) memset(((void *) &controlVelocidad_B), 0,
                sizeof(B_controlVelocidad_T));

  /* states (dwork) */
  (void) memset((void *)&controlVelocidad_DW, 0,
                sizeof(DW_controlVelocidad_T));

  /* Start for MATLABSystem: '<S17>/Digital Output' */
  controlVelocidad_DW.obj_n.isInitialized = 0L;
  controlVelocidad_DW.objisempty_c = true;
  controlVelocidad_DW.obj_n.isInitialized = 1L;
  digitalIOSetup((uint8_T)controlVelocidad_PinNumber, true);

  /* Start for S-Function (arduinoanalogoutput_sfcn): '<S18>/PWM' */
  MW_pinModeOutput(controlVelocidad_P.PWM_pinNumber);

  /* Start for MATLABSystem: '<S22>/Digital Output' */
  controlVelocidad_DW.obj.isInitialized = 0L;
  controlVelocidad_DW.objisempty = true;
  controlVelocidad_DW.obj.isInitialized = 1L;
  digitalIOSetup((uint8_T)controlVelocidad_PinNumber_f, true);

  /* Start for S-Function (arduinoanalogoutput_sfcn): '<S23>/PWM' */
  MW_pinModeOutput(controlVelocidad_P.PWM_pinNumber_l);

  /* Start for S-Function (arduinoanalogoutput_sfcn): '<S24>/PWM' */
  MW_pinModeOutput(controlVelocidad_P.PWM_pinNumber_a);
  controlVelocidad_PrevZCX.TriggeredSubsystem_Trig_ZCE = POS_ZCSIG;

  /* InitializeConditions for S-Function (sfcn_encoder): '<S11>/EncoderIP2' */

  /* S-Function Block: <S11>/EncoderIP2 */
  {
    real_T initVector[1] = { 0 };

    {
      int_T i1;
      for (i1=0; i1 < 1; i1++) {
        controlVelocidad_DW.EncoderIP2_DSTATE = initVector[0];
      }
    }
  }

  /* InitializeConditions for UnitDelay: '<S15>/UD' */
  controlVelocidad_DW.UD_DSTATE =
    controlVelocidad_P.DiscreteDerivative_ICPrevScaled;

  /* InitializeConditions for S-Function (sfcn_direccion): '<S19>/EncoderDP2' */

  /* S-Function Block: <S19>/EncoderDP2 */
  {
    real_T initVector[1] = { 0 };

    {
      int_T i1;
      for (i1=0; i1 < 1; i1++) {
        controlVelocidad_DW.EncoderDP2_DSTATE = initVector[0];
      }
    }
  }

  /* InitializeConditions for S-Function (comunicaciones): '<Root>/S-Function Builder' */

  /* S-Function Block: <Root>/S-Function Builder */
  {
    real_T initVector[1] = { 0 };

    {
      int_T i1;
      for (i1=0; i1 < 1; i1++) {
        controlVelocidad_DW.SFunctionBuilder_DSTATE = initVector[0];
      }
    }
  }

  /* InitializeConditions for DiscreteIntegrator: '<S25>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE = controlVelocidad_P.Integrator_IC;
  controlVelocidad_DW.Integrator_PrevResetState = 0;

  /* InitializeConditions for DiscreteIntegrator: '<S25>/Filter' */
  controlVelocidad_DW.Filter_DSTATE = controlVelocidad_P.Filter_IC;
  controlVelocidad_DW.Filter_PrevResetState = 0;

  /* InitializeConditions for DiscreteIntegrator: '<S26>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE_g = controlVelocidad_P.Integrator_IC_a;
  controlVelocidad_DW.Integrator_PrevResetState_a = 0;

  /* InitializeConditions for DiscreteIntegrator: '<S26>/Filter' */
  controlVelocidad_DW.Filter_DSTATE_i = controlVelocidad_P.Filter_IC_l;
  controlVelocidad_DW.Filter_PrevResetState_k = 0;

  /* InitializeConditions for DiscreteIntegrator: '<S28>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE_b = controlVelocidad_P.Integrator_IC_c;
  controlVelocidad_DW.Integrator_PrevResetState_l = 2;

  /* InitializeConditions for DiscreteIntegrator: '<S28>/Filter' */
  controlVelocidad_DW.Filter_DSTATE_p = controlVelocidad_P.Filter_IC_n;
  controlVelocidad_DW.Filter_PrevResetState_d = 2;

  /* InitializeConditions for DiscreteIntegrator: '<S27>/Integrator' */
  controlVelocidad_DW.Integrator_DSTATE_c = controlVelocidad_P.Integrator_IC_n;
  controlVelocidad_DW.Integrator_PrevResetState_o = 2;

  /* InitializeConditions for DiscreteIntegrator: '<S27>/Filter' */
  controlVelocidad_DW.Filter_DSTATE_m = controlVelocidad_P.Filter_IC_m;
  controlVelocidad_DW.Filter_PrevResetState_l = 2;

  /* SystemInitialize for Triggered SubSystem: '<S3>/Triggered Subsystem' */
  /* SystemInitialize for Outport: '<S10>/Out1' */
  controlVelocidad_B.In1 = controlVelocidad_P.Out1_Y0;

  /* End of SystemInitialize for SubSystem: '<S3>/Triggered Subsystem' */
}

/* Model terminate function */
void controlVelocidad_terminate(void)
{
  /* Start for MATLABSystem: '<S17>/Digital Output' incorporates:
   *  Terminate for MATLABSystem: '<S17>/Digital Output'
   */
  if (controlVelocidad_DW.obj_n.isInitialized == 1L) {
    controlVelocidad_DW.obj_n.isInitialized = 2L;
  }

  /* End of Start for MATLABSystem: '<S17>/Digital Output' */

  /* Start for MATLABSystem: '<S22>/Digital Output' incorporates:
   *  Terminate for MATLABSystem: '<S22>/Digital Output'
   */
  if (controlVelocidad_DW.obj.isInitialized == 1L) {
    controlVelocidad_DW.obj.isInitialized = 2L;
  }

  /* End of Start for MATLABSystem: '<S22>/Digital Output' */
}
