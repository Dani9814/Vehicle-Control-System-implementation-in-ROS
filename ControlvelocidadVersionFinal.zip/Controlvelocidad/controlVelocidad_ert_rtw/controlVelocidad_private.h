/*
 * controlVelocidad_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "controlVelocidad".
 *
 * Model version              : 1.17
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Jun 28 17:23:39 2018
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controlVelocidad_private_h_
#define RTW_HEADER_controlVelocidad_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void sfcn_encoder_Outputs_wrapper(int32_T *pos,
    uint32_T *time,
    uint8_T *n,
    const real_T *xD,
    const uint8_T *enc, const int_T p_width0,
    const uint8_T *pinA, const int_T p_width1,
    const uint8_T *pinB, const int_T p_width2);
  extern void sfcn_encoder_Update_wrapper(int32_T *pos,
    uint32_T *time,
    uint8_T *n,
    real_T *xD,
    const uint8_T *enc, const int_T p_width0,
    const uint8_T *pinA, const int_T p_width1,
    const uint8_T *pinB, const int_T p_width2);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void sfcn_direccion_Outputs_wrapper(real_T *pos,
    uint32_T *time,
    const real_T *xD,
    const uint8_T *enc, const int_T p_width0,
    const uint8_T *pinA, const int_T p_width1,
    const uint8_T *pinB, const int_T p_width2);
  extern void sfcn_direccion_Update_wrapper(real_T *pos,
    uint32_T *time,
    real_T *xD,
    const uint8_T *enc, const int_T p_width0,
    const uint8_T *pinA, const int_T p_width1,
    const uint8_T *pinB, const int_T p_width2);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void comunicaciones_Outputs_wrapper(const int16_T *vsin,
    const int16_T *wsin,
    int16_T *vs,
    int16_T *ws,
    const real_T *xD);
  extern void comunicaciones_Update_wrapper(const int16_T *vsin,
    const int16_T *wsin,
    int16_T *vs,
    int16_T *ws,
    real_T *xD);

#ifdef __cplusplus

}
#endif

extern real_T rt_roundd_snf(real_T u);

#endif                                 /* RTW_HEADER_controlVelocidad_private_h_ */
