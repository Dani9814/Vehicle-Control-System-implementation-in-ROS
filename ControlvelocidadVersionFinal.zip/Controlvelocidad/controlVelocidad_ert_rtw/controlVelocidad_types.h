/*
 * controlVelocidad_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "controlVelocidad".
 *
 * Model version              : 1.17
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Jun 28 17:23:39 2018
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controlVelocidad_types_h_
#define RTW_HEADER_controlVelocidad_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef typedef_codertarget_arduinobase_block_T
#define typedef_codertarget_arduinobase_block_T

typedef struct {
  int32_T isInitialized;
} codertarget_arduinobase_block_T;

#endif                                 /*typedef_codertarget_arduinobase_block_T*/

#ifndef typedef_struct_T_controlVelocidad_T
#define typedef_struct_T_controlVelocidad_T

typedef struct {
  real_T f1[2];
} struct_T_controlVelocidad_T;

#endif                                 /*typedef_struct_T_controlVelocidad_T*/

#ifndef typedef_struct_T_controlVelocidad_f_T
#define typedef_struct_T_controlVelocidad_f_T

typedef struct {
  char_T f1[7];
} struct_T_controlVelocidad_f_T;

#endif                                 /*typedef_struct_T_controlVelocidad_f_T*/

#ifndef typedef_struct_T_controlVelocidad_fu_T
#define typedef_struct_T_controlVelocidad_fu_T

typedef struct {
  char_T f1[4];
  char_T f2[11];
  char_T f3[7];
  char_T f4[6];
} struct_T_controlVelocidad_fu_T;

#endif                                 /*typedef_struct_T_controlVelocidad_fu_T*/

/* Parameters (auto storage) */
typedef struct P_controlVelocidad_T_ P_controlVelocidad_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_controlVelocidad_T RT_MODEL_controlVelocidad_T;

#endif                                 /* RTW_HEADER_controlVelocidad_types_h_ */
