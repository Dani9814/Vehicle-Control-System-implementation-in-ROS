/*
 * controlVelocidad.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "controlVelocidad".
 *
 * Model version              : 1.17
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Jun 28 17:23:39 2018
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controlVelocidad_h_
#define RTW_HEADER_controlVelocidad_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#ifndef controlVelocidad_COMMON_INCLUDES_
# define controlVelocidad_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "MW_digitalio.h"
#include "arduino_analogoutput_lct.h"
#endif                                 /* controlVelocidad_COMMON_INCLUDES_ */

#include "controlVelocidad_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Radiodelarueda15cm;           /* '<S12>/Radio de la rueda= 15cm' */
  real_T EncoderDP2_o1;                /* '<S19>/EncoderDP2' */
  real_T Gain;                         /* '<S1>/Gain' */
  real_T Sum1;                         /* '<S3>/Sum1' */
  real_T Switch1;                      /* '<S7>/Switch1' */
  real_T Switch;                       /* '<S8>/Switch' */
  real_T In1;                          /* '<S10>/In1' */
  real_T Sum_ci;                       /* '<S3>/Sum' */
  real_T Gain_n;                       /* '<S20>/Gain' */
  real_T ReductoraDireccin;            /* '<S19>/Reductora Dirección' */
  real_T rtb_Gain_n_m;
  real_T IntegralGain_m;               /* '<S28>/Integral Gain' */
  real_T IntegralGain_b;               /* '<S27>/Integral Gain' */
  real_T IntegralGain;                 /* '<S25>/Integral Gain' */
  int32_T EncoderIP2_o1;               /* '<S11>/EncoderIP2' */
  uint32_T EncoderIP2_o2;              /* '<S11>/EncoderIP2' */
  uint32_T EncoderDP2_o2;              /* '<S19>/EncoderDP2' */
  int16_T DataTypeConversion;          /* '<S2>/Data Type Conversion' */
  int16_T DataTypeConversion1;         /* '<S2>/Data Type Conversion1' */
  int16_T SFunctionBuilder_o1;         /* '<Root>/S-Function Builder' */
  int16_T SFunctionBuilder_o2;         /* '<Root>/S-Function Builder' */
  uint8_T EncoderIP2_o3;               /* '<S11>/EncoderIP2' */
  uint8_T Saturation;                  /* '<S20>/Saturation' */
  uint8_T Saturation1;                 /* '<S20>/Saturation1' */
  boolean_T Compare;                   /* '<S29>/Compare' */
} B_controlVelocidad_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T EncoderIP2_DSTATE;            /* '<S11>/EncoderIP2' */
  real_T UD_DSTATE;                    /* '<S15>/UD' */
  real_T EncoderDP2_DSTATE;            /* '<S19>/EncoderDP2' */
  real_T SFunctionBuilder_DSTATE;      /* '<Root>/S-Function Builder' */
  real_T Integrator_DSTATE;            /* '<S25>/Integrator' */
  real_T Filter_DSTATE;                /* '<S25>/Filter' */
  real_T Integrator_DSTATE_g;          /* '<S26>/Integrator' */
  real_T Filter_DSTATE_i;              /* '<S26>/Filter' */
  real_T Integrator_DSTATE_b;          /* '<S28>/Integrator' */
  real_T Filter_DSTATE_p;              /* '<S28>/Filter' */
  real_T Integrator_DSTATE_c;          /* '<S27>/Integrator' */
  real_T Filter_DSTATE_m;              /* '<S27>/Filter' */
  void *DigitalOutput_PWORK;           /* '<S22>/Digital Output' */
  void *DigitalOutput_PWORK_n;         /* '<S17>/Digital Output' */
  codertarget_arduinobase_block_T obj; /* '<S22>/Digital Output' */
  codertarget_arduinobase_block_T obj_n;/* '<S17>/Digital Output' */
  int8_T Integrator_PrevResetState;    /* '<S25>/Integrator' */
  int8_T Filter_PrevResetState;        /* '<S25>/Filter' */
  int8_T Integrator_PrevResetState_a;  /* '<S26>/Integrator' */
  int8_T Filter_PrevResetState_k;      /* '<S26>/Filter' */
  int8_T Integrator_PrevResetState_l;  /* '<S28>/Integrator' */
  int8_T Filter_PrevResetState_d;      /* '<S28>/Filter' */
  int8_T Integrator_PrevResetState_o;  /* '<S27>/Integrator' */
  int8_T Filter_PrevResetState_l;      /* '<S27>/Filter' */
  boolean_T objisempty;                /* '<S22>/Digital Output' */
  boolean_T objisempty_c;              /* '<S17>/Digital Output' */
} DW_controlVelocidad_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S3>/Triggered Subsystem' */
} PrevZCX_controlVelocidad_T;

/* Parameters (auto storage) */
struct P_controlVelocidad_T_ {
  real_T PIDcarga_D;                   /* Mask Parameter: PIDcarga_D
                                        * Referenced by: '<S25>/Derivative Gain'
                                        */
  real_T PIDsincarga_D;                /* Mask Parameter: PIDsincarga_D
                                        * Referenced by: '<S26>/Derivative Gain'
                                        */
  real_T PIDSincarga_D;                /* Mask Parameter: PIDSincarga_D
                                        * Referenced by: '<S28>/Derivative Gain'
                                        */
  real_T PIDConcarga_D;                /* Mask Parameter: PIDConcarga_D
                                        * Referenced by: '<S27>/Derivative Gain'
                                        */
  real_T PIDcarga_I;                   /* Mask Parameter: PIDcarga_I
                                        * Referenced by: '<S25>/Integral Gain'
                                        */
  real_T PIDsincarga_I;                /* Mask Parameter: PIDsincarga_I
                                        * Referenced by: '<S26>/Integral Gain'
                                        */
  real_T PIDConcarga_I;                /* Mask Parameter: PIDConcarga_I
                                        * Referenced by: '<S27>/Integral Gain'
                                        */
  real_T PIDSincarga_I;                /* Mask Parameter: PIDSincarga_I
                                        * Referenced by: '<S28>/Integral Gain'
                                        */
  real_T DiscreteDerivative_ICPrevScaled;/* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                          * Referenced by: '<S15>/UD'
                                          */
  real_T PIDcarga_N;                   /* Mask Parameter: PIDcarga_N
                                        * Referenced by: '<S25>/Filter Coefficient'
                                        */
  real_T PIDsincarga_N;                /* Mask Parameter: PIDsincarga_N
                                        * Referenced by: '<S26>/Filter Coefficient'
                                        */
  real_T PIDSincarga_N;                /* Mask Parameter: PIDSincarga_N
                                        * Referenced by: '<S28>/Filter Coefficient'
                                        */
  real_T PIDConcarga_N;                /* Mask Parameter: PIDConcarga_N
                                        * Referenced by: '<S27>/Filter Coefficient'
                                        */
  real_T PIDcarga_P;                   /* Mask Parameter: PIDcarga_P
                                        * Referenced by: '<S25>/Proportional Gain'
                                        */
  real_T PIDsincarga_P;                /* Mask Parameter: PIDsincarga_P
                                        * Referenced by: '<S26>/Proportional Gain'
                                        */
  real_T PIDSincarga_P;                /* Mask Parameter: PIDSincarga_P
                                        * Referenced by: '<S28>/Proportional Gain'
                                        */
  real_T PIDConcarga_P;                /* Mask Parameter: PIDConcarga_P
                                        * Referenced by: '<S27>/Proportional Gain'
                                        */
  real_T CompareToConstant_const;      /* Mask Parameter: CompareToConstant_const
                                        * Referenced by: '<S29>/Constant'
                                        */
  uint32_T PWM_pinNumber;              /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S18>/PWM'
                                        */
  uint32_T PWM_pinNumber_l;            /* Mask Parameter: PWM_pinNumber_l
                                        * Referenced by: '<S23>/PWM'
                                        */
  uint32_T PWM_pinNumber_a;            /* Mask Parameter: PWM_pinNumber_a
                                        * Referenced by: '<S24>/PWM'
                                        */
  real_T Out1_Y0;                      /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S10>/Out1'
                                        */
  real_T CARGA_Value;                  /* Expression: 0
                                        * Referenced by: '<Root>/CARGA'
                                        */
  real_T u024cpr2interrupcionCuentaFlanc;/* Expression: pi/(1024*2)
                                          * Referenced by: '<S13>/1024cpr*2interrupcion Cuenta Flanco de subida y de bajada'
                                          */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S15>/TSamp'
                                        */
  real_T relaciontransmisionperdidas094R;/* Expression: 16*0.94/35
                                          * Referenced by: '<S12>/relacion transmision perdidas= 0.94 Rueda conductora 16 dientes Rueda conducida 35 dientes'
                                          */
  real_T Radiodelarueda15cm_Gain;      /* Expression: 0.15
                                        * Referenced by: '<S12>/Radio de la rueda= 15cm'
                                        */
  real_T Gain_Gain;                    /* Expression: 100
                                        * Referenced by: '<S2>/Gain'
                                        */
  real_T pulsestodegrees_Gain;         /* Expression: 360/(500*2*36)
                                        * Referenced by: '<S19>/pulses to degrees'
                                        */
  real_T ReductoraDireccin_Gain;       /* Expression: 1/3.8
                                        * Referenced by: '<S19>/Reductora Dirección'
                                        */
  real_T Gain1_Gain;                   /* Expression: 100
                                        * Referenced by: '<S2>/Gain1'
                                        */
  real_T Gain2_Gain;                   /* Expression: pi/180
                                        * Referenced by: '<S2>/Gain2'
                                        */
  real_T Gain_Gain_j;                  /* Expression: 0.01
                                        * Referenced by: '<S1>/Gain'
                                        */
  real_T Gain1_Gain_j;                 /* Expression: 0.01
                                        * Referenced by: '<S1>/Gain1'
                                        */
  real_T Gain1_Gain_n;                 /* Expression: 180/pi
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T Gain_Gain_l;                  /* Expression: -1
                                        * Referenced by: '<S3>/Gain'
                                        */
  real_T Constant_Value;               /* Expression: 80.0
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S4>/Constant2'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S4>/Switch1'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real_T Constant_Value_e;             /* Expression: 1
                                        * Referenced by: '<S7>/Constant'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S25>/Integrator'
                                        */
  real_T Integrator_IC;                /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S25>/Integrator'
                                        */
  real_T Filter_gainval;               /* Computed Parameter: Filter_gainval
                                        * Referenced by: '<S25>/Filter'
                                        */
  real_T Filter_IC;                    /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S25>/Filter'
                                        */
  real_T Integrator_gainval_a;         /* Computed Parameter: Integrator_gainval_a
                                        * Referenced by: '<S26>/Integrator'
                                        */
  real_T Integrator_IC_a;              /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S26>/Integrator'
                                        */
  real_T Filter_gainval_i;             /* Computed Parameter: Filter_gainval_i
                                        * Referenced by: '<S26>/Filter'
                                        */
  real_T Filter_IC_l;                  /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S26>/Filter'
                                        */
  real_T Switch_Threshold;             /* Expression: 55
                                        * Referenced by: '<S7>/Switch'
                                        */
  real_T Constant_Value_p;             /* Expression: 0
                                        * Referenced by: '<S16>/Constant'
                                        */
  real_T Integrator_gainval_f;         /* Computed Parameter: Integrator_gainval_f
                                        * Referenced by: '<S28>/Integrator'
                                        */
  real_T Integrator_IC_c;              /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S28>/Integrator'
                                        */
  real_T Filter_gainval_k;             /* Computed Parameter: Filter_gainval_k
                                        * Referenced by: '<S28>/Filter'
                                        */
  real_T Filter_IC_n;                  /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S28>/Filter'
                                        */
  real_T Integrator_gainval_e;         /* Computed Parameter: Integrator_gainval_e
                                        * Referenced by: '<S27>/Integrator'
                                        */
  real_T Integrator_IC_n;              /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S27>/Integrator'
                                        */
  real_T Filter_gainval_p;             /* Computed Parameter: Filter_gainval_p
                                        * Referenced by: '<S27>/Filter'
                                        */
  real_T Filter_IC_m;                  /* Expression: InitialConditionForFilter
                                        * Referenced by: '<S27>/Filter'
                                        */
  real_T Switch_Threshold_b;           /* Expression: 55
                                        * Referenced by: '<S8>/Switch'
                                        */
  real_T Constant2_Value_n;            /* Expression: 130
                                        * Referenced by: '<S9>/Constant2'
                                        */
  real_T Switch1_Threshold_a;          /* Expression: 2
                                        * Referenced by: '<S9>/Switch1'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S21>/Constant'
                                        */
  real_T Gain_Gain_d;                  /* Expression: -1
                                        * Referenced by: '<S20>/Gain'
                                        */
  uint8_T EncoderIP2_P1;               /* Expression: uint8(1)
                                        * Referenced by: '<S11>/EncoderIP2'
                                        */
  uint8_T EncoderIP2_P2;               /* Expression: uint8(18)
                                        * Referenced by: '<S11>/EncoderIP2'
                                        */
  uint8_T EncoderIP2_P3;               /* Expression: uint8(19)
                                        * Referenced by: '<S11>/EncoderIP2'
                                        */
  uint8_T EncoderDP2_P1;               /* Expression: uint8(0)
                                        * Referenced by: '<S19>/EncoderDP2'
                                        */
  uint8_T EncoderDP2_P2;               /* Expression: uint8(2)
                                        * Referenced by: '<S19>/EncoderDP2'
                                        */
  uint8_T EncoderDP2_P3;               /* Expression: uint8(3)
                                        * Referenced by: '<S19>/EncoderDP2'
                                        */
  uint8_T Saturation_UpperSat;         /* Computed Parameter: Saturation_UpperSat
                                        * Referenced by: '<S14>/Saturation'
                                        */
  uint8_T Saturation_LowerSat;         /* Computed Parameter: Saturation_LowerSat
                                        * Referenced by: '<S14>/Saturation'
                                        */
  uint8_T Saturation_UpperSat_g;       /* Computed Parameter: Saturation_UpperSat_g
                                        * Referenced by: '<S20>/Saturation'
                                        */
  uint8_T Saturation_LowerSat_m;       /* Computed Parameter: Saturation_LowerSat_m
                                        * Referenced by: '<S20>/Saturation'
                                        */
  uint8_T Saturation1_UpperSat;        /* Computed Parameter: Saturation1_UpperSat
                                        * Referenced by: '<S20>/Saturation1'
                                        */
  uint8_T Saturation1_LowerSat;        /* Computed Parameter: Saturation1_LowerSat
                                        * Referenced by: '<S20>/Saturation1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_controlVelocidad_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern P_controlVelocidad_T controlVelocidad_P;

/* Block signals (auto storage) */
extern B_controlVelocidad_T controlVelocidad_B;

/* Block states (auto storage) */
extern DW_controlVelocidad_T controlVelocidad_DW;

/* Model entry point functions */
extern void controlVelocidad_initialize(void);
extern void controlVelocidad_step(void);
extern void controlVelocidad_terminate(void);

/* Real-time Model object */
extern RT_MODEL_controlVelocidad_T *const controlVelocidad_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Display1' : Unused code path elimination
 * Block '<S5>/nºinterrupciones' : Unused code path elimination
 * Block '<S15>/Data Type Duplicate' : Unused code path elimination
 * Block '<S19>/posicion' : Unused code path elimination
 * Block '<S19>/posicion1' : Unused code path elimination
 * Block '<Root>/speed' : Unused code path elimination
 * Block '<Root>/steering' : Unused code path elimination
 * Block '<S18>/Data Type Conversion' : Eliminate redundant data type conversion
 * Block '<S23>/Data Type Conversion' : Eliminate redundant data type conversion
 * Block '<S24>/Data Type Conversion' : Eliminate redundant data type conversion
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'controlVelocidad'
 * '<S1>'   : 'controlVelocidad/Cambio de unidades  '
 * '<S2>'   : 'controlVelocidad/Cambio de unidades  y redondeo'
 * '<S3>'   : 'controlVelocidad/VEHICULO TRICICLO'
 * '<S4>'   : 'controlVelocidad/VEHICULO TRICICLO/Espera  Homing'
 * '<S5>'   : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed'
 * '<S6>'   : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering'
 * '<S7>'   : 'controlVelocidad/VEHICULO TRICICLO/PID speed'
 * '<S8>'   : 'controlVelocidad/VEHICULO TRICICLO/PID steering'
 * '<S9>'   : 'controlVelocidad/VEHICULO TRICICLO/Posicionado Rueda HOMING'
 * '<S10>'  : 'controlVelocidad/VEHICULO TRICICLO/Triggered Subsystem'
 * '<S11>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/Encoder throttle'
 * '<S12>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/Subsystem1'
 * '<S13>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/pulses to speed'
 * '<S14>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/throttle H-bridge'
 * '<S15>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/pulses to speed/Discrete Derivative'
 * '<S16>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/throttle H-bridge/Compare To Zero1'
 * '<S17>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/throttle H-bridge/Direccion'
 * '<S18>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Speed/throttle H-bridge/PWM'
 * '<S19>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering/Direction'
 * '<S20>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering/Steering'
 * '<S21>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering/Steering/Compare To Zero1'
 * '<S22>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering/Steering/DireccionIzda2'
 * '<S23>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering/Steering/MotorIzqa 2'
 * '<S24>'  : 'controlVelocidad/VEHICULO TRICICLO/Open Loop Steering/Steering/MotorIzqa 4'
 * '<S25>'  : 'controlVelocidad/VEHICULO TRICICLO/PID speed/PID carga'
 * '<S26>'  : 'controlVelocidad/VEHICULO TRICICLO/PID speed/PID sin carga'
 * '<S27>'  : 'controlVelocidad/VEHICULO TRICICLO/PID steering/PID Con carga'
 * '<S28>'  : 'controlVelocidad/VEHICULO TRICICLO/PID steering/PID Sin carga'
 * '<S29>'  : 'controlVelocidad/VEHICULO TRICICLO/Posicionado Rueda HOMING/Compare To Constant'
 */
#endif                                 /* RTW_HEADER_controlVelocidad_h_ */
