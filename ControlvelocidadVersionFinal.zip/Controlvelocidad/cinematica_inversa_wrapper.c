

/*
 * Include Files
 *
 */
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#include "rtwtypes.h"
#endif



/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */
#include <math.h>
#define pi 3.141592653589793
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */
#define u_width 1
#define y_width 1
/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */
/* extern double func(double a); */
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output functions
 *
 */
void cinematica_inversa_Outputs_wrapper(const real_T *v,
			const real_T *w,
			real_T *stearing,
			real_T *vlineal,
			const real_T *xD)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */
/* This sample sets the output equal to the input
      y0[0] = u0[0]; 
 For complex signals use: y0[0].re = u0[0].re; 
      y0[0].im = u0[0].im;
      y1[0].re = u1[0].re;
      y1[0].im = u1[0].im;
*/

if (xD[0]==1) {
    
#ifndef MATLAB_MEX_FILE
       // inderterminacion
       if (v[0]==0 && w[0]>0){
            vlineal[0]=0.1;
            stearing[0]=-120;
       }
       else if (v[0]==0 && w[0]<0){
            vlineal[0]=0.1;
            stearing[0]=120;
       }
       else if(v[0]==0 && w[0]==0){
           //se para y conserva el stearing
            vlineal[0]=0;
       //Existe una �ica posicion.
       }
       else{  
            stearing[0]=180*atan(w[0]*1.3*2*pi/(60*v[0]))/pi;
            vlineal[0]= v[0]/cos(atan(w[0]*1.3*2*pi/(60*v[0])));
       }
       


#endif
}
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}

/*
 * Updates function
 *
 */
void cinematica_inversa_Update_wrapper(const real_T *v,
			const real_T *w,
			real_T *stearing,
			real_T *vlineal,
			real_T *xD)
{
/* %%%-SFUNWIZ_wrapper_Update_Changes_BEGIN --- EDIT HERE TO _END */
/*
 * Code example
 *   xD[0] = u0[0];
*/

if (xD[0]!=1) {
    
    /* don't do anything for MEX-file generation */
  //  # ifndef MATLAB_MEX_FILE
    stearing[0]=0;
    vlineal[0]=0;
   // # endif
    
    /* initialization done */ 
    xD[0]=1;
}
/* %%%-SFUNWIZ_wrapper_Update_Changes_END --- EDIT HERE TO _BEGIN */
}
