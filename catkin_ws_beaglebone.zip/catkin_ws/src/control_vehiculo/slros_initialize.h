#ifndef _SLROS_INITIALIZE_H_
#define _SLROS_INITIALIZE_H_

#include "slros_busmsg_conversion.h"
#include "slros_generic.h"

extern ros::NodeHandle * SLROSNodePtr;
extern const std::string SLROSNodeName;

// For Block control_vehiculo/Subscribe
extern SimulinkSubscriber<sensor_msgs::Joy, SL_Bus_control_vehiculo_sensor_msgs_Joy> Sub_control_vehiculo_1;

// For Block control_vehiculo/Publish
extern SimulinkPublisher<geometry_msgs::Twist, SL_Bus_control_vehiculo_geometry_msgs_Twist> Pub_control_vehiculo_546;

void slros_node_init(int argc, char** argv);

#endif
