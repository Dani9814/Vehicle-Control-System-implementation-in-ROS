//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: control_vehiculo.h
//
// Code generated for Simulink model 'control_vehiculo'.
//
// Model version                  : 1.30
// Simulink Coder version         : 8.13 (R2017b) 24-Jul-2017
// C/C++ source code generated on : Fri Apr 20 18:14:57 2018
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_control_vehiculo_h_
#define RTW_HEADER_control_vehiculo_h_
#include <math.h>
#include <stddef.h>
#include <string.h>
#ifndef control_vehiculo_COMMON_INCLUDES_
# define control_vehiculo_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "slros_initialize.h"
#endif                                 // control_vehiculo_COMMON_INCLUDES_

#include "control_vehiculo_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

// Block signals (auto storage)
typedef struct {
  SL_Bus_control_vehiculo_sensor_msgs_Joy In1;// '<S8>/In1'
  SL_Bus_control_vehiculo_sensor_msgs_Joy b_varargout_2;
} B_control_vehiculo_T;

// Block states (auto storage) for system '<Root>'
typedef struct {
  robotics_slros_internal_block_T obj; // '<S3>/SinkBlock'
  robotics_slros_internal_blo_e_T obj_n;// '<S4>/SourceBlock'
} DW_control_vehiculo_T;

// Parameters (auto storage)
struct P_control_vehiculo_T_ {
  SL_Bus_control_vehiculo_sensor_msgs_Joy Out1_Y0;// Computed Parameter: Out1_Y0
                                                  //  Referenced by: '<S8>/Out1'

  SL_Bus_control_vehiculo_sensor_msgs_Joy Constant_Value;// Computed Parameter: Constant_Value
                                                         //  Referenced by: '<S4>/Constant'

  SL_Bus_control_vehiculo_geometry_msgs_Twist Constant_Value_b;// Computed Parameter: Constant_Value_b
                                                               //  Referenced by: '<S1>/Constant'

  real32_T porlosdosdecimales2_Gain;   // Computed Parameter: porlosdosdecimales2_Gain
                                       //  Referenced by: '<S5>/por los dos  decimales 2'

  real32_T porlosdosdecimales1_Gain;   // Computed Parameter: porlosdosdecimales1_Gain
                                       //  Referenced by: '<S5>/por los dos  decimales 1'

  real32_T quitarleslosnegativos_Bias; // Computed Parameter: quitarleslosnegativos_Bias
                                       //  Referenced by: '<S5>/quitarles los  negativos'

  real32_T porlosdosdecimales_Gain;    // Computed Parameter: porlosdosdecimales_Gain
                                       //  Referenced by: '<S5>/por los dos  decimales '

};

// Real-time Model Data Structure
struct tag_RTM_control_vehiculo_T {
  const char_T *errorStatus;
};

// Class declaration for model control_vehiculo
class receptorModelClass {
  // public data and function members
 public:
  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  receptorModelClass();

  // Destructor
  ~receptorModelClass();

  // Real-Time Model get method
  RT_MODEL_control_vehiculo_T * getRTM();

  // private data and function members
 private:
  // Tunable parameters
  P_control_vehiculo_T control_vehiculo_P;

  // Block signals
  B_control_vehiculo_T control_vehiculo_B;

  // Block states
  DW_control_vehiculo_T control_vehiculo_DW;

  // Real-Time Model
  RT_MODEL_control_vehiculo_T control_vehiculo_M;
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S2>/Display1' : Unused code path elimination
//  Block '<S2>/Display10' : Unused code path elimination
//  Block '<S2>/Display11' : Unused code path elimination
//  Block '<S2>/Display12' : Unused code path elimination
//  Block '<S2>/Display13' : Unused code path elimination
//  Block '<S2>/Display14' : Unused code path elimination
//  Block '<S2>/Display15' : Unused code path elimination
//  Block '<S2>/Display16' : Unused code path elimination
//  Block '<S2>/Display17' : Unused code path elimination
//  Block '<S2>/Display18' : Unused code path elimination
//  Block '<S2>/Display2' : Unused code path elimination
//  Block '<S2>/Display3' : Unused code path elimination
//  Block '<S2>/Display4' : Unused code path elimination
//  Block '<S2>/Display7' : Unused code path elimination
//  Block '<S2>/Display8' : Unused code path elimination
//  Block '<S2>/Display9' : Unused code path elimination
//  Block '<S5>/Display' : Unused code path elimination


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'control_vehiculo'
//  '<S1>'   : 'control_vehiculo/Blank Message'
//  '<S2>'   : 'control_vehiculo/Msg to X,Y'
//  '<S3>'   : 'control_vehiculo/Publish'
//  '<S4>'   : 'control_vehiculo/Subscribe'
//  '<S5>'   : 'control_vehiculo/x y to V W'
//  '<S6>'   : 'control_vehiculo/Msg to X,Y/Subsystem'
//  '<S7>'   : 'control_vehiculo/Msg to X,Y/Subsystem1'
//  '<S8>'   : 'control_vehiculo/Subscribe/Enabled Subsystem'

#endif                                 // RTW_HEADER_control_vehiculo_h_

//
// File trailer for generated code.
//
// [EOF]
//
