#include "slros_initialize.h"

ros::NodeHandle * SLROSNodePtr;
const std::string SLROSNodeName = "control_vehiculo";

// For Block control_vehiculo/Subscribe
SimulinkSubscriber<sensor_msgs::Joy, SL_Bus_control_vehiculo_sensor_msgs_Joy> Sub_control_vehiculo_1;

// For Block control_vehiculo/Publish
SimulinkPublisher<geometry_msgs::Twist, SL_Bus_control_vehiculo_geometry_msgs_Twist> Pub_control_vehiculo_546;

void slros_node_init(int argc, char** argv)
{
  ros::init(argc, argv, SLROSNodeName);
  SLROSNodePtr = new ros::NodeHandle();
}

