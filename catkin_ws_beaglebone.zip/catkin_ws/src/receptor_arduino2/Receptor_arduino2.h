//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: Receptor_arduino2.h
//
// Code generated for Simulink model 'Receptor_arduino2'.
//
// Model version                  : 1.28
// Simulink Coder version         : 8.13 (R2017b) 24-Jul-2017
// C/C++ source code generated on : Tue Apr 17 22:37:12 2018
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Linux 64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_Receptor_arduino2_h_
#define RTW_HEADER_Receptor_arduino2_h_
#include <math.h>
#include <stddef.h>
#include <string.h>
#ifndef Receptor_arduino2_COMMON_INCLUDES_
# define Receptor_arduino2_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "slros_initialize.h"
#endif                                 // Receptor_arduino2_COMMON_INCLUDES_

#include "Receptor_arduino2_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

// Block signals (auto storage)
typedef struct {
  SL_Bus_Receptor_arduino2_sensor_msgs_Joy In1;// '<S8>/In1'
  SL_Bus_Receptor_arduino2_sensor_msgs_Joy b_varargout_2;
} B_Receptor_arduino2_T;

// Block states (auto storage) for system '<Root>'
typedef struct {
  robotics_slros_internal_block_T obj; // '<S3>/SinkBlock'
  robotics_slros_internal_blo_j_T obj_n;// '<S4>/SourceBlock'
} DW_Receptor_arduino2_T;

// Parameters (auto storage)
struct P_Receptor_arduino2_T_ {
  SL_Bus_Receptor_arduino2_sensor_msgs_Joy Out1_Y0;// Computed Parameter: Out1_Y0
                                                   //  Referenced by: '<S8>/Out1'

  SL_Bus_Receptor_arduino2_sensor_msgs_Joy Constant_Value;// Computed Parameter: Constant_Value
                                                          //  Referenced by: '<S4>/Constant'

  SL_Bus_Receptor_arduino2_geometry_msgs_Twist Constant_Value_b;// Computed Parameter: Constant_Value_b
                                                                //  Referenced by: '<S1>/Constant'

  real32_T quitarleslosnegativos_Bias; // Computed Parameter: quitarleslosnegativos_Bias
                                       //  Referenced by: '<S5>/quitarles los  negativos'

  real32_T porlosdosdecimales_Gain;    // Computed Parameter: porlosdosdecimales_Gain
                                       //  Referenced by: '<S5>/por los dos  decimales '

};

// Real-time Model Data Structure
struct tag_RTM_Receptor_arduino2_T {
  const char_T *errorStatus;
};

// Class declaration for model Receptor_arduino2
class receptorModelClass {
  // public data and function members
 public:
  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  receptorModelClass();

  // Destructor
  ~receptorModelClass();

  // Real-Time Model get method
  RT_MODEL_Receptor_arduino2_T * getRTM();

  // private data and function members
 private:
  // Tunable parameters
  P_Receptor_arduino2_T Receptor_arduino2_P;

  // Block signals
  B_Receptor_arduino2_T Receptor_arduino2_B;

  // Block states
  DW_Receptor_arduino2_T Receptor_arduino2_DW;

  // Real-Time Model
  RT_MODEL_Receptor_arduino2_T Receptor_arduino2_M;
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S2>/Display1' : Unused code path elimination
//  Block '<S2>/Display10' : Unused code path elimination
//  Block '<S2>/Display11' : Unused code path elimination
//  Block '<S2>/Display12' : Unused code path elimination
//  Block '<S2>/Display13' : Unused code path elimination
//  Block '<S2>/Display14' : Unused code path elimination
//  Block '<S2>/Display15' : Unused code path elimination
//  Block '<S2>/Display16' : Unused code path elimination
//  Block '<S2>/Display17' : Unused code path elimination
//  Block '<S2>/Display18' : Unused code path elimination
//  Block '<S2>/Display2' : Unused code path elimination
//  Block '<S2>/Display3' : Unused code path elimination
//  Block '<S2>/Display4' : Unused code path elimination
//  Block '<S2>/Display7' : Unused code path elimination
//  Block '<S2>/Display8' : Unused code path elimination
//  Block '<S2>/Display9' : Unused code path elimination
//  Block '<S5>/Display' : Unused code path elimination


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'Receptor_arduino2'
//  '<S1>'   : 'Receptor_arduino2/Blank Message'
//  '<S2>'   : 'Receptor_arduino2/Msg to X,Y'
//  '<S3>'   : 'Receptor_arduino2/Publish'
//  '<S4>'   : 'Receptor_arduino2/Subscribe'
//  '<S5>'   : 'Receptor_arduino2/x y to V W'
//  '<S6>'   : 'Receptor_arduino2/Msg to X,Y/Subsystem'
//  '<S7>'   : 'Receptor_arduino2/Msg to X,Y/Subsystem1'
//  '<S8>'   : 'Receptor_arduino2/Subscribe/Enabled Subsystem'

#endif                                 // RTW_HEADER_Receptor_arduino2_h_

//
// File trailer for generated code.
//
// [EOF]
//
