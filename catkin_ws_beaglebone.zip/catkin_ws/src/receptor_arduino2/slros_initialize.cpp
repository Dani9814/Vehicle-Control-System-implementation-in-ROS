#include "slros_initialize.h"

ros::NodeHandle * SLROSNodePtr;
const std::string SLROSNodeName = "Receptor_arduino2";

// For Block Receptor_arduino2/Subscribe
SimulinkSubscriber<sensor_msgs::Joy, SL_Bus_Receptor_arduino2_sensor_msgs_Joy> Sub_Receptor_arduino2_1;

// For Block Receptor_arduino2/Publish
SimulinkPublisher<geometry_msgs::Twist, SL_Bus_Receptor_arduino2_geometry_msgs_Twist> Pub_Receptor_arduino2_546;

void slros_node_init(int argc, char** argv)
{
  ros::init(argc, argv, SLROSNodeName);
  SLROSNodePtr = new ros::NodeHandle();
}

