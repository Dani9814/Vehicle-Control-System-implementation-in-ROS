#!/usr/bin/env python

import rospy
import serial
import math
from geometry_msgs.msg import Twist
ser = serial.Serial('/dev/ttyACM0',115200)


def callback(msg):
	V= math.sqrt(math.pow(msg.linear.x,2)+math.pow(msg.linear.y,2))
	W=msg.angular.z
#Message
	Vlsb=int(V%256)
	Vmsb=int(V//256)
	Wlsb=int(W%256)
	Wmsb=int(W//256)
        if (200+1+Vlsb+Vmsb+Wlsb+Wmsb)%256==0:
		cheacksum=0
	else:
		cheacksum=int(256-(200+1+Vlsb+Vmsb+Wlsb+Wmsb)%256)

	ser.write(bytearray([200,1,Vlsb,Vmsb,Wlsb,Wmsb,cheacksum]))
	
	
rospy.init_node('hola')
sub = rospy.Subscriber("Arduino_reference",Twist,callback)
rospy.spin()
